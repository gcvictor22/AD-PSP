package com.salesianostriana.dam.trianafy.model;

import java.io.Serializable;

public class AddedToPk implements Serializable {

    private Long song_id;
    private Long playlist_id;

}
